import java.sql.*;
import java.util.Scanner;
public class ReserveEvent {
    public static void reserve(String user) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Event Name: ");
        String e = sc.nextLine();
        System.out.print("Seats: ");
        int s = sc.nextInt();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps1 =
                con.prepareStatement("SELECT price FROM events WHERE event_name=?");
            ps1.setString(1, e);
            ResultSet rs = ps1.executeQuery();
            if (rs.next()) {
                double total = rs.getDouble(1) * s;
                PreparedStatement ps2 =
                    con.prepareStatement("INSERT INTO reservations VALUES(NULL,?,?,?,?)");
                ps2.setString(1, user);
                ps2.setString(2, e);
                ps2.setInt(3, s);
                ps2.setDouble(4, total);
                ps2.executeUpdate();
                System.out.println("Booking Successful. Amount: ₹" + total);
            }
        } catch (Exception ex) {}
    }
}