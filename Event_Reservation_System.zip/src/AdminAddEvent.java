import java.sql.*;
import java.util.Scanner;
public class AdminAddEvent {
    public static void addEvent() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Event Name: ");
        String name = sc.nextLine();
        System.out.print("Location: ");
        String loc = sc.nextLine();
        System.out.print("Date: ");
        String date = sc.nextLine();
        System.out.print("Seats: ");
        int seats = sc.nextInt();
        System.out.print("Price: ");
        double price = sc.nextDouble();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO events(event_name,location,date,seats,price) VALUES(?,?,?,?,?)"
            );
            ps.setString(1, name);
            ps.setString(2, loc);
            ps.setString(3, date);
            ps.setInt(4, seats);
            ps.setDouble(5, price);
            ps.executeUpdate();
            System.out.println("Event Added Successfully");
        } catch (Exception e) {}
    }
}