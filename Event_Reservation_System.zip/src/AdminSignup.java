import java.sql.*;
import java.util.Scanner;
public class AdminSignup {
    public static void signup() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Admin Username: ");
        String u = sc.nextLine();
        System.out.print("Password: ");
        String p = sc.nextLine();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("INSERT INTO admins(username,password) VALUES(?,?)");
            ps.setString(1, u);
            ps.setString(2, p);
            ps.executeUpdate();
            System.out.println("Admin registered successfully");
        } catch (Exception e) {
            System.out.println("Error");
        }
    }
}