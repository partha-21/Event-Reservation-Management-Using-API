import java.util.Scanner;
public class MainMenu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== EVENT RESERVATION SYSTEM ===");
            System.out.println("1. Admin Login");
            System.out.println("2. Admin Signup");
            System.out.println("3. User Login");
            System.out.println("4. User Signup");
            System.out.println("5. Exit");
            System.out.print("Choose: ");
            int ch = sc.nextInt();
            switch (ch) {
                case 1 -> AdminLogin.login();
                case 2 -> AdminSignup.signup();
                case 3 -> UserLogin.login();
                case 4 -> UserSignup.signup();
                case 5 -> System.exit(0);
                default -> System.out.println("Invalid choice");
            }
        }
    }
}