import java.sql.*;
public class ViewEvents {
    public static void view() {
        try (Connection con = DBConnection.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM events");
            System.out.println("\n--- EVENTS ---");
            while (rs.next()) {
                System.out.println(
                    rs.getString("event_name") + " | " +
                    rs.getString("location") + " | " +
                    rs.getString("date") + " | ₹" +
                    rs.getDouble("price")
                );
            }
        } catch (Exception e) {}
    }
}