import java.sql.*;
import java.util.Scanner;
public class UserLogin {
    public static void login() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Username: ");
        String u = sc.nextLine();
        System.out.print("Password: ");
        String p = sc.nextLine();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("SELECT * FROM users WHERE username=? AND password=?");
            ps.setString(1, u);
            ps.setString(2, p);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ViewEvents.view();
                ReserveEvent.reserve(u);
            } else {
                System.out.println("Invalid Login");
            }
        } catch (Exception e) {}
    }
}