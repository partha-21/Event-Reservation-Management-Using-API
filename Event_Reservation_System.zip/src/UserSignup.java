import java.sql.*;
import java.util.Scanner;
public class UserSignup {
    public static void signup() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Name: ");
        String n = sc.nextLine();
        System.out.print("Username: ");
        String u = sc.nextLine();
        System.out.print("Password: ");
        String p = sc.nextLine();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("INSERT INTO users(name,username,password) VALUES(?,?,?)");
            ps.setString(1, n);
            ps.setString(2, u);
            ps.setString(3, p);
            ps.executeUpdate();
            System.out.println("User Registered");
        } catch (Exception e) {}
    }
}