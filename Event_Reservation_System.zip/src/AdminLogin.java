import java.sql.*;
import java.util.Scanner;
public class AdminLogin {
    public static void login() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Username: ");
        String u = sc.nextLine();
        System.out.print("Password: ");
        String p = sc.nextLine();
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps =
                con.prepareStatement("SELECT * FROM admins WHERE username=? AND password=?");
            ps.setString(1, u);
            ps.setString(2, p);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Admin Login Success");
                AdminAddEvent.addEvent();
            } else {
                System.out.println("Invalid Admin Credentials");
            }
        } catch (Exception e) {}
    }
}